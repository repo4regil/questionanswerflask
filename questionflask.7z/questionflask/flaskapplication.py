#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#import libraries
import gspread
from flask import Flask, render_template,request,redirect

#Object for service account
gc = gspread.service_account(filename='credentials.json')

#object of the google sheet
sheet_id = '1LXzqij3y-BSAoot35nA9c2X-Vziuco_sa0IpOccD4AQ'
sh = gc.open_by_key(sheet_id)

#get the worksheet
worksheet = sh.sheet1

#available data in the worksheet is
records = worksheet.get_all_records()

#code for flask app
app = Flask(__name__)

@app.route('/', methods=['POST','GET'])
def mainpage():
   
    if 'submit_button' in request.form:

        quest = request.form['question_inp']

        found = False
        for record in records:

            if quest == record['question']:
                
                found = True
                ans1 = record['answer1']
                ans2 = record['answer2']
                ans3 = record['answer3']
                
        if found == False:
            ans1,ans2,ans3 = 'NA','NA','NA'
            qstn_ans = [quest, ans1, ans2, ans3]

            worksheet.append_row(qstn_ans)       #adding the new question in google sheet
        
        return render_template('index.html',question = quest, answer1=ans1,answer2 =ans2,answer3=ans3)
    else:
        
        return render_template('index.html',question=' ', answer1=' ',answer2 = ' ',answer3= ' ')
    

if __name__ == "__main__":
    
    app.run(debug=True, use_reloader=False)


# In[ ]:




